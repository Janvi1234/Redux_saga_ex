export const COLOR ='color'

export const changeColor=(data)=>{
   return{
    type:COLOR,
    payload:data
   }
}